"""
Random forest with cross-validation
Part of the "Machine Learning" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

from sklearn.datasets import load_wine
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score

X, y = load_wine(return_X_y=True)
m = RandomForestClassifier(n_estimators=300, random_state=0)
scores = cross_val_score(m, X, y, cv=5, scoring="accuracy")
print(f"CV accuracy: {scores.mean():.3f} +/- {scores.std():.3f}")
m.fit(X, y)
print("Feature importances (top 5):",
      sorted(enumerate(m.feature_importances_), key=lambda t: -t[1])[:5])
