"""
Linear regression by gradient descent
Part of the "Machine Learning" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

import numpy as np
np.random.seed(1)

# Synthetic data: y = 3x + 2 + noise
X = np.linspace(0, 10, 200).reshape(-1,1)
y = 3*X.flatten() + 2 + np.random.randn(200)

w, b, lr = 0.0, 0.0, 0.01
for epoch in range(2000):
    pred = (X.flatten()*w + b)
    err = pred - y
    w -= lr * (err * X.flatten()).mean()
    b -= lr * err.mean()
print(f"Learned: y = {w:.3f} x + {b:.3f}  (truth: 3 x + 2)")
