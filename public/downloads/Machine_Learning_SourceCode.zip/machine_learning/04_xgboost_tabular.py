"""
XGBoost on tabular data with early stopping
Part of the "Machine Learning" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

"""pip install xgboost scikit-learn"""
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
import xgboost as xgb

X, y = fetch_california_housing(return_X_y=True)
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=0)
model = xgb.XGBRegressor(n_estimators=600, max_depth=6, learning_rate=0.05,
                         early_stopping_rounds=20, eval_metric="mae")
model.fit(Xtr, ytr, eval_set=[(Xte, yte)], verbose=False)
print("MAE:", mean_absolute_error(yte, model.predict(Xte)))
