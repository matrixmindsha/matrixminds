"""
Logistic regression with scikit-learn
Part of the "Machine Learning" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, roc_auc_score

X, y = load_breast_cancer(return_X_y=True)
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=0)
sc = StandardScaler().fit(Xtr)
m = LogisticRegression(max_iter=2000).fit(sc.transform(Xtr), ytr)
p = m.predict_proba(sc.transform(Xte))[:,1]
print(classification_report(yte, p>0.5))
print("ROC-AUC:", roc_auc_score(yte, p))
