"""
Serve a model behind a FastAPI endpoint
Part of the "Machine Learning" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

"""pip install fastapi uvicorn scikit-learn joblib
Train + serve:  python 05_serve_with_fastapi.py train
                uvicorn 05_serve_with_fastapi:app --reload
"""
import sys, joblib
from fastapi import FastAPI
from pydantic import BaseModel

MODEL_PATH = "iris.joblib"

if __name__ == "__main__" and len(sys.argv) > 1 and sys.argv[1] == "train":
    from sklearn.datasets import load_iris
    from sklearn.ensemble import RandomForestClassifier
    X, y = load_iris(return_X_y=True)
    joblib.dump(RandomForestClassifier().fit(X, y), MODEL_PATH)
    print("trained ->", MODEL_PATH); raise SystemExit

class Flower(BaseModel):
    sepal_length: float; sepal_width: float
    petal_length: float; petal_width: float

app = FastAPI()
model = joblib.load(MODEL_PATH) if __name__ != "__main__" else None

@app.post("/predict")
def predict(f: Flower):
    pred = int(model.predict([[f.sepal_length, f.sepal_width,
                               f.petal_length, f.petal_width]])[0])
    return {"class": pred}
