# Data Science — Source Code
Drafted by S. Hareedh, Matrix Minds.
Install: `pip install pandas seaborn matplotlib streamlit plotly`.
