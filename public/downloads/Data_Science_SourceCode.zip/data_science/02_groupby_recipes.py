"""
Useful pandas groupby recipes
Part of the "Data Science" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

import pandas as pd, numpy as np
df = pd.DataFrame({
    "city": ["A","A","B","B","C","C"]*2,
    "month":[1,2]*6,
    "sales":np.random.randint(100,500,12),
    "cost": np.random.randint(40,200,12),
})
df["profit"] = df["sales"] - df["cost"]
print(df.groupby("city").agg(sales=("sales","sum"),
                             profit=("profit","sum"),
                             margin=("profit", lambda s: s.sum()/df.loc[s.index,"sales"].sum())))
# Pivot table
print(df.pivot_table(index="city", columns="month", values="sales", aggfunc="sum"))
# Window: running total
df = df.sort_values(["city","month"])
df["running_sales"] = df.groupby("city")["sales"].cumsum()
print(df)
