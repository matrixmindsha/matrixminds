"""
End-to-end EDA on the Titanic dataset
Part of the "Data Science" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

"""pip install pandas seaborn matplotlib"""
import pandas as pd, seaborn as sns, matplotlib.pyplot as plt
df = sns.load_dataset("titanic")
print(df.info())
print(df.describe(include="all").T)
print("Missing %:\n", (df.isna().mean()*100).round(1))
print("Survival by class:\n", df.groupby("class")["survived"].mean())
print("Survival by sex:\n", df.groupby("sex")["survived"].mean())
sns.histplot(df["age"].dropna(), bins=30); plt.title("Age distribution"); plt.show()
