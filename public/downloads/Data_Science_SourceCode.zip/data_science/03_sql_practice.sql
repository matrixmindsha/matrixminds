-- Data Science — SQL practice queries
-- Drafted by S. Hareedh, Matrix Minds.

-- 1. Top 5 customers by lifetime revenue
SELECT customer_id, SUM(amount) AS lifetime_revenue
FROM orders
GROUP BY customer_id
ORDER BY lifetime_revenue DESC
LIMIT 5;

-- 2. Monthly active users
SELECT DATE_TRUNC('month', event_at) AS month,
       COUNT(DISTINCT user_id) AS mau
FROM events
GROUP BY 1
ORDER BY 1;

-- 3. Rolling 7-day revenue with a window function
SELECT order_date,
       SUM(amount) AS daily,
       SUM(SUM(amount)) OVER (ORDER BY order_date
                              ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS rolling_7d
FROM orders
GROUP BY order_date
ORDER BY order_date;

-- 4. Cohort retention: users who came in January and were still active in February
WITH jan AS (
  SELECT DISTINCT user_id FROM events
  WHERE event_at >= '2026-01-01' AND event_at < '2026-02-01'
)
SELECT COUNT(DISTINCT e.user_id) * 1.0 / (SELECT COUNT(*) FROM jan) AS retention
FROM events e JOIN jan USING (user_id)
WHERE e.event_at >= '2026-02-01' AND e.event_at < '2026-03-01';
