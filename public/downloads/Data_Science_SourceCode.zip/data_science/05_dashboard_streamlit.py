"""
Quick analytical dashboard with Streamlit
Part of the "Data Science" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

"""pip install streamlit pandas plotly
Run: streamlit run 05_dashboard_streamlit.py"""
import streamlit as st, pandas as pd, plotly.express as px, numpy as np
np.random.seed(0)
df = pd.DataFrame({"date": pd.date_range("2026-01-01", periods=90),
                   "revenue": np.random.gamma(2, 2000, 90).round(),
                   "channel": np.random.choice(["organic","ads","referral"], 90)})
st.title("Matrix Minds — Sample Dashboard")
ch = st.multiselect("Channel", df.channel.unique(), default=list(df.channel.unique()))
sub = df[df.channel.isin(ch)]
st.metric("Total revenue", f"₹ {sub.revenue.sum():,.0f}")
st.plotly_chart(px.line(sub.groupby("date").revenue.sum().reset_index(),
                        x="date", y="revenue", title="Daily revenue"))
