"""
A/B test analysis: two-proportion z-test
Part of the "Data Science" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

import math
def ab_test(visitors_a, conv_a, visitors_b, conv_b):
    pa, pb = conv_a/visitors_a, conv_b/visitors_b
    p_pool = (conv_a+conv_b)/(visitors_a+visitors_b)
    se = math.sqrt(p_pool*(1-p_pool)*(1/visitors_a + 1/visitors_b))
    z = (pb - pa)/se
    # two-tailed p approx via erfc
    p_val = math.erfc(abs(z)/math.sqrt(2))
    lift = (pb-pa)/pa*100
    return {"conv_a":pa, "conv_b":pb, "lift_pct":lift, "z":z, "p_value":p_val}

if __name__ == "__main__":
    print(ab_test(10000, 520, 10000, 610))
