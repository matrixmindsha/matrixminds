"""
SQLi: vulnerable code vs the parameterised fix
Part of the "Ethical Hacking" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

"""Demonstrates SQL injection and the correct defence.
Educational use only — do not run unsafe_login() against any real database."""
import sqlite3

def setup():
    c = sqlite3.connect(":memory:")
    c.execute("CREATE TABLE users(id INTEGER, name TEXT, password TEXT)")
    c.execute("INSERT INTO users VALUES (1,'admin','s3cret'), (2,'alice','pw')")
    c.commit(); return c

def unsafe_login(conn, name, password):
    # NEVER DO THIS — string concatenation = SQL injection
    q = f"SELECT id FROM users WHERE name='{name}' AND password='{password}'"
    return conn.execute(q).fetchone()

def safe_login(conn, name, password):
    return conn.execute(
        "SELECT id FROM users WHERE name=? AND password=?", (name, password)
    ).fetchone()

if __name__ == "__main__":
    conn = setup()
    # The classic ' OR '1'='1 payload
    print("unsafe with injection :", unsafe_login(conn, "admin", "' OR '1'='1"))
    print("safe   with injection :", safe_login(conn,   "admin", "' OR '1'='1"))
    print("safe   with real creds:", safe_login(conn,   "admin", "s3cret"))
