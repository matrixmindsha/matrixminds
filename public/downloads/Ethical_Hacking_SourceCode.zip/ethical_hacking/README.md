# Ethical Hacking — Source Code

Drafted by S. Hareedh, Matrix Minds.

## LEGAL NOTICE
Every script here is for **defensive learning and authorised testing only**.
Run them only against:
- Your own machines (`127.0.0.1`, your home lab VMs)
- Intentionally vulnerable practice apps (OWASP Juice Shop, DVWA, Metasploitable)
- Targets you have explicit written permission to test (a pentest scope, a bug bounty programme)

Unauthorised use is illegal under the IT Act 2000 (India), the Computer Fraud
and Abuse Act (US), the Computer Misuse Act (UK), and equivalent laws worldwide.

Install: `pip install bcrypt`.
