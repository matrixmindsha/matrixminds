"""
Password strength auditor + bcrypt hashing demo
Part of the "Ethical Hacking" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

"""pip install bcrypt"""
import re, bcrypt

def strength(pw: str) -> dict:
    checks = {
        "length>=12": len(pw) >= 12,
        "has_upper":  bool(re.search(r"[A-Z]", pw)),
        "has_lower":  bool(re.search(r"[a-z]", pw)),
        "has_digit":  bool(re.search(r"\d",   pw)),
        "has_symbol": bool(re.search(r"[^\w\s]", pw)),
        "not_common": pw.lower() not in {"password","123456","qwerty","admin"},
    }
    score = sum(checks.values())
    return {"score": f"{score}/6", **checks}

def hash_password(pw: str) -> bytes:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt(rounds=12))

if __name__ == "__main__":
    pw = "MatrixMinds@2026!"
    print(strength(pw))
    print("hash:", hash_password(pw))
