"""
Directory discovery against a target you own
Part of the "Ethical Hacking" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

"""
LEGAL NOTICE: Only run against hosts you own or have explicit permission to test
(e.g. juice-shop running on http://127.0.0.1:3000).
"""
import sys, urllib.request, concurrent.futures

WORDS = ["admin","login","api","backup","config","robots.txt",".env","uploads",
         "dashboard","old","test","staging","dev","static","assets"]

def probe(base, word):
    url = base.rstrip("/") + "/" + word
    try:
        req = urllib.request.Request(url, method="HEAD")
        code = urllib.request.urlopen(req, timeout=3).status
    except Exception as e:
        code = getattr(e, "code", None)
    return word, code

if __name__ == "__main__":
    base = sys.argv[1] if len(sys.argv)>1 else "http://127.0.0.1:3000"
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
        for w_, code in ex.map(lambda w_: probe(base, w_), WORDS):
            if code and code != 404:
                print(f"  [{code}] /{w_}")
