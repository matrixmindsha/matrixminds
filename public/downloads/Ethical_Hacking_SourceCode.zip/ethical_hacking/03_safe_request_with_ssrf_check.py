"""
Outbound HTTP fetcher with SSRF allow-list
Part of the "Ethical Hacking" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

"""
Defensive pattern: never fetch a user-supplied URL without
1) parsing it, 2) resolving it, 3) blocking private/loopback ranges.
"""
import ipaddress, socket, urllib.parse, urllib.request

ALLOWED_SCHEMES = {"http", "https"}

def is_safe(url: str) -> bool:
    p = urllib.parse.urlparse(url)
    if p.scheme not in ALLOWED_SCHEMES: return False
    try:
        host = p.hostname
        ip = ipaddress.ip_address(socket.gethostbyname(host))
        return not (ip.is_private or ip.is_loopback or ip.is_link_local
                    or ip.is_reserved or ip.is_multicast)
    except Exception:
        return False

def safe_get(url: str, timeout=5) -> str:
    if not is_safe(url):
        raise PermissionError("Blocked by SSRF guard: " + url)
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return r.read(64*1024).decode("utf-8", "replace")

if __name__ == "__main__":
    print(safe_get("https://example.com")[:200])
    try: safe_get("http://169.254.169.254/")  # AWS metadata
    except PermissionError as e: print("blocked:", e)
