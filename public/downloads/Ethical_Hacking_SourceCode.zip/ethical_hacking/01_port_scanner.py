"""
Concurrent TCP port scanner (use only on systems you own)
Part of the "Ethical Hacking" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

"""
LEGAL NOTICE: Only scan hosts you own or have written permission to test.
Unauthorised scanning is illegal in most countries.
"""
import socket, concurrent.futures, sys

def scan(host, port, timeout=0.5):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(timeout)
        try:
            s.connect((host, port)); return port
        except Exception:
            return None

if __name__ == "__main__":
    host = sys.argv[1] if len(sys.argv)>1 else "127.0.0.1"
    ports = range(1, 1025)
    with concurrent.futures.ThreadPoolExecutor(max_workers=200) as ex:
        open_ports = [p for p in ex.map(lambda p: scan(host,p), ports) if p]
    print(f"Open ports on {host}: {open_ports}")
