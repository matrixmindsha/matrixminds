"""
A single-neuron perceptron from scratch
Part of the "AI Mastery" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

import numpy as np

class Perceptron:
    def __init__(self, n_features, lr=0.1, epochs=20):
        self.w = np.zeros(n_features); self.b = 0.0
        self.lr = lr; self.epochs = epochs

    def predict(self, X):
        return np.where(X @ self.w + self.b >= 0, 1, 0)

    def fit(self, X, y):
        for _ in range(self.epochs):
            for xi, yi in zip(X, y):
                err = yi - (1 if xi @ self.w + self.b >= 0 else 0)
                self.w += self.lr * err * xi
                self.b += self.lr * err
        return self

if __name__ == "__main__":
    # Learn the AND function
    X = np.array([[0,0],[0,1],[1,0],[1,1]])
    y = np.array([0,0,0,1])
    p = Perceptron(2).fit(X, y)
    print("AND predictions:", p.predict(X).tolist())
