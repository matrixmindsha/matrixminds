"""
Minimal chat client for any OpenAI-compatible API
Part of the "AI Mastery" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

"""
Works with OpenAI, Lovable AI Gateway, Together, Groq, etc.
Set BASE_URL and API_KEY env vars.
"""
import os, json, urllib.request

BASE_URL = os.getenv("BASE_URL", "https://api.openai.com/v1")
API_KEY  = os.getenv("API_KEY", "")
MODEL    = os.getenv("MODEL", "gpt-4o-mini")

def chat(messages):
    req = urllib.request.Request(
        f"{BASE_URL}/chat/completions",
        data=json.dumps({"model": MODEL, "messages": messages}).encode(),
        headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())["choices"][0]["message"]["content"]

if __name__ == "__main__":
    history = [{"role": "system", "content": "You are a concise helpful assistant."}]
    while True:
        try: u = input("you> ")
        except EOFError: break
        if not u: break
        history.append({"role":"user","content":u})
        a = chat(history)
        history.append({"role":"assistant","content":a})
        print("ai>", a)
