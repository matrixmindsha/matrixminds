"""
Two-layer neural network in pure NumPy
Part of the "AI Mastery" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

import numpy as np
np.random.seed(0)

def sigmoid(x): return 1/(1+np.exp(-x))
def dsigmoid(y): return y*(1-y)

# XOR cannot be solved by a single perceptron — needs a hidden layer.
X = np.array([[0,0],[0,1],[1,0],[1,1]])
Y = np.array([[0],[1],[1],[0]])

W1 = np.random.randn(2,4); b1 = np.zeros((1,4))
W2 = np.random.randn(4,1); b2 = np.zeros((1,1))
lr = 0.5

for epoch in range(10000):
    h = sigmoid(X @ W1 + b1)
    out = sigmoid(h @ W2 + b2)
    err = Y - out
    d_out = err * dsigmoid(out)
    d_h = d_out @ W2.T * dsigmoid(h)
    W2 += h.T @ d_out * lr; b2 += d_out.sum(0, keepdims=True)*lr
    W1 += X.T @ d_h  * lr; b1 += d_h.sum(0, keepdims=True)*lr
    if epoch % 2000 == 0:
        print(f"epoch {epoch} loss {np.mean(err**2):.4f}")
print("XOR predictions:", out.round(2).flatten().tolist())
