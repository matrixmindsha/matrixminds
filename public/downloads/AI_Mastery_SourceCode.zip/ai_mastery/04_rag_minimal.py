"""
Minimal Retrieval-Augmented Generation example
Part of the "AI Mastery" bundle by Matrix Minds.
Drafted by S. Hareedh — Founder, Matrix Minds.
License: MIT (for educational use).
"""

"""
A toy RAG: TF-IDF retrieval over local .txt files, then prompt the LLM.
Run: python 04_rag_minimal.py ./docs "your question"
"""
import sys, os, glob, math, re
from collections import Counter

def tokenize(t): return re.findall(r"[a-z0-9]+", t.lower())

def load(folder):
    docs = []
    for path in glob.glob(os.path.join(folder, "*.txt")):
        with open(path) as f: docs.append((path, f.read()))
    return docs

def score(query, docs):
    q = Counter(tokenize(query))
    results = []
    for path, text in docs:
        toks = tokenize(text)
        c = Counter(toks)
        s = sum(q[w] * c[w] for w in q) / (math.sqrt(len(toks)) + 1)
        results.append((s, path, text))
    return sorted(results, reverse=True)[:3]

if __name__ == "__main__":
    folder, q = sys.argv[1], sys.argv[2]
    top = score(q, load(folder))
    context = "\n\n---\n\n".join(t[:800] for _,_,t in top)
    print("CONTEXT FOUND:")
    print(context[:1500])
    print("\nNow send this to your LLM as: 'Answer the question using only the context above. Question:', q")
